#include <iostream>
using namespace std;

struct Product {
    char name[50];
    int code;
    float price;
};

int main() {
    int n;

    cout << "Enter number of products: ";
    cin >> n;


    Product* products = new Product[n];

 
    for (int i = 0; i < n; i++) {
        cout << "\nProduct " << i + 1 << ":\n";
        cout << "Enter name: ";
        cin >> products[i].name;
        cout << "Enter code: ";
        cin >> products[i].code;
        cout << "Enter price: ";
        cin >> products[i].price;
    }

   
    cout << "\n--- Product List ---\n";
    for (int i = 0; i < n; i++) {
        cout << "Name: " << products[i].name << "\n";
        cout << "Code: " << products[i].code << "\n";
        cout << "Price: " << products[i].price << "\n\n";
    }

    
    delete[] products;

    return 0;
}
