#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void initializeList() {
    int arr[] = {1, 45, 60, 12};
    Node* last = NULL;
    for (int i = 0; i < 4; i++) {
        Node* temp = new Node();
        temp->data = arr[i];
        temp->prev = last;
        temp->next = NULL;
        if (last != NULL) last->next = temp;
        else head = temp;
        last = temp;
    }
}

void display() {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void insertAtBeginning(int val) {
    Node* temp = new Node();
    temp->data = val;
    temp->prev = NULL;
    temp->next = head;
    if (head != NULL) head->prev = temp;
    head = temp;
}

void insertAfterValue(int key, int val) {
    Node* temp = head;
    while (temp != NULL && temp->data != key) temp = temp->next;
    if (temp == NULL) return;
    Node* newNode = new Node();
    newNode->data = val;
    newNode->next = temp->next;
    newNode->prev = temp;
    if (temp->next != NULL) temp->next->prev = newNode;
    temp->next = newNode;
}

void deleteAtBeginning() {
    if (head == NULL) return;
    Node* temp = head;
    head = head->next;
    if (head != NULL) head->prev = NULL;
    delete temp;
}

void deleteAfterValue(int key) {
    Node* temp = head;
    while (temp != NULL && temp->data != key) temp = temp->next;
    if (temp == NULL || temp->next == NULL) return;
    Node* delNode = temp->next;
    temp->next = delNode->next;
    if (delNode->next != NULL) delNode->next->prev = temp;
    delete delNode;
}

int main() {
    initializeList();
    cout << "Initial list: ";
    display();

    insertAtBeginning(99);
    cout << "After inserting 99 at beginning: ";
    display();

    insertAfterValue(45, 77);
    cout << "After inserting 77 after 45: ";
    display();

    deleteAtBeginning();
    cout << "After deleting at beginning: ";
    display();

    deleteAfterValue(45);
    cout << "After deleting node after 45: ";
    display();

    return 0;
}

