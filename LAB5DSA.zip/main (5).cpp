#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void insertAtEnd(int val) {
    Node* temp = new Node();
    temp->data = val;
    temp->next = NULL;
    if (head == NULL) {
        temp->prev = NULL;
        head = temp;
        return;
    }
    Node* curr = head;
    while (curr->next != NULL) curr = curr->next;
    curr->next = temp;
    temp->prev = curr;
}

void display() {
    Node* temp = head;
    int day = 1;
    while (temp != NULL) {
        cout << "Day " << day << ": " << temp->data << endl;
        temp = temp->next;
        day++;
    }
}

void analyzeRainfall() {
    if (head == NULL) return;

    int total = 0, count = 0;
    int highest = head->data, lowest = head->data;
    int highDay = 1, lowDay = 1;

    Node* temp = head;
    int day = 1;
    while (temp != NULL) {
        total += temp->data;
        if (temp->data > highest) {
            highest = temp->data;
            highDay = day;
        }
        if (temp->data < lowest) {
            lowest = temp->data;
            lowDay = day;
        }
        temp = temp->next;
        count++;
        day++;
    }

    cout << "\nTotal Rainfall: " << total;
    cout << "\nAverage Rainfall: " << (float)total / count;
    cout << "\nHighest Rainfall: " << highest << " on Day " << highDay;
    cout << "\nLowest Rainfall: " << lowest << " on Day " << lowDay;

    Node* after5 = head;
    for (int i = 1; i <= 5 && after5 != NULL; i++) {
        after5 = after5->next;
    }
    if (after5 != NULL)
        cout << "\nRainfall of day after 5th node (Day 6): " << after5->data;
    else
        cout << "\nNo day exists after 5th node!";
}

int main() {
    cout << "Enter rainfall for 7 days:\n";
    for (int i = 1; i <= 7; i++) {
        int rain;
        cout << "Day " << i << ": ";
        cin >> rain;
        insertAtEnd(rain);
    }

    cout << "\nRainfall Data:\n";
    display();

    analyzeRainfall();

    return 0;
}


