#include <iostream>
#include <string>
using namespace std;

struct Node {
    string name;
    int score;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void insertPlayer(string name, int score) {
    Node* newNode = new Node();
    newNode->name = name;
    newNode->score = score;
    newNode->prev = newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp != NULL && temp->score <= score) {
        if (temp->next == NULL) break;
        if (temp->next->score > score) break;
        temp = temp->next;
    }

    if (temp == head && score < temp->score) {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    else if (temp->next == NULL && score >= temp->score) {
        temp->next = newNode;
        newNode->prev = temp;
    }
    else {
        newNode->next = temp->next;
        newNode->prev = temp;
        if (temp->next != NULL) temp->next->prev = newNode;
        temp->next = newNode;
    }
}

void deletePlayer(string name) {
    if (head == NULL) return;
    Node* temp = head;

    while (temp != NULL && temp->name != name) temp = temp->next;

    if (temp == NULL) {
        cout << "Player not found.\n";
        return;
    }

    if (temp == head) head = temp->next;
    if (temp->prev != NULL) temp->prev->next = temp->next;
    if (temp->next != NULL) temp->next->prev = temp->prev;

    delete temp;
    cout << "Player deleted.\n";
}

void displayAll() {
    Node* temp = head;
    cout << "\nPlayer List:\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}

void displayLowest() {
    if (head == NULL) {
        cout << "List empty.\n";
        return;
    }
    cout << "Lowest Score: " << head->name << " - " << head->score << endl;
}

void displaySameScore(int score) {
    Node* temp = head;
    bool found = false;
    cout << "\nPlayers with score " << score << ":\n";
    while (temp != NULL) {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No players with this score.\n";
}

void displayBackwardFrom(string name) {
    Node* temp = head;
    while (temp != NULL && temp->name != name) temp = temp->next;

    if (temp == NULL) {
        cout << "Player not found.\n";
        return;
    }

    cout << "\nBackward from " << name << ":\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->prev;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add new player\n";
        cout << "2. Delete player\n";
        cout << "3. Display all players\n";
        cout << "4. Display player with lowest score\n";
        cout << "5. Display players with same score\n";
        cout << "6. Display backward from a player\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            string name; int score;
            cout << "Enter player name: ";
            cin >> name;
            cout << "Enter score: ";
            cin >> score;
            insertPlayer(name, score);
        }
        else if (choice == 2) {
            string name;
            cout << "Enter player name to delete: ";
            cin >> name;
            deletePlayer(name);
        }
        else if (choice == 3) {
            displayAll();
        }
        else if (choice == 4) {
            displayLowest();
        }
        else if (choice == 5) {
            int s;
            cout << "Enter score: ";
            cin >> s;
            displaySameScore(s);
        }
        else if (choice == 6) {
            string name;
            cout << "Enter player name: ";
            cin >> name;
            displayBackwardFrom(name);
        }
        else if (choice == 7) break;
        else cout << "Invalid choice.\n";
    }
    return 0;
}
