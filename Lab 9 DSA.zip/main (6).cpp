#include <iostream>
#include <string>
using namespace std;

struct Applicant {
    int id;
    float height;
    float weight;
    float eyesight;
    string status;
    Applicant* next;
    Applicant* prev;
};

class ApplicantQueue {
private:
    Applicant* front;
    Applicant* rear;

public:
    ApplicantQueue() {
        front = rear = nullptr;
    }

    void enqueue(int id, float height, float weight, float eyesight, string status) {
        Applicant* newNode = new Applicant{id, height, weight, eyesight, status, nullptr, nullptr};
        if (rear == nullptr) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
    }

    void dequeue() {
        if (front == nullptr) {
            cout << "No applicant in queue.\n";
            return;
        }
        Applicant* temp = front;
        front = front->next;
        if (front) front->prev = nullptr;
        else rear = nullptr;
        cout << "Applicant " << temp->id << " has given the test and left the queue.\n";
        delete temp;
    }

    void removeSecond() {
        if (front == nullptr || front->next == nullptr) {
            cout << "Not enough applicants to remove 2nd one.\n";
            return;
        }
        Applicant* temp = front->next;
        cout << "Applicant " << temp->id << " left the line due to urgency.\n";
        front->next = temp->next;
        if (temp->next) temp->next->prev = front;
        else rear = front;
        delete temp;
    }

    void display() {
        if (!front) {
            cout << "Queue is empty.\n";
            return;
        }
        cout << "\nCurrent Queue:\n";
        Applicant* temp = front;
        while (temp) {
            cout << "ID: " << temp->id
                 << " | Height: " << temp->height
                 << " | Weight: " << temp->weight
                 << " | Eyesight: " << temp->eyesight
                 << " | Status: " << temp->status << endl;
            temp = temp->next;
        }
    }
};

int main() {
    ApplicantQueue q;
    q.enqueue(1, 5.6, 60, 6.0, "waiting");
    q.enqueue(2, 5.7, 70, 5.5, "waiting");
    q.enqueue(3, 6.0, 68, 6.2, "waiting");
    q.enqueue(4, 5.8, 72, 6.1, "waiting");
    q.enqueue(5, 5.9, 65, 6.0, "waiting");
    q.enqueue(6, 6.1, 75, 5.8, "waiting");
    q.enqueue(7, 5.5, 55, 6.3, "waiting");
    q.display();
    q.removeSecond();
    q.display();
    q.dequeue();
    q.display();
    return 0;
}
