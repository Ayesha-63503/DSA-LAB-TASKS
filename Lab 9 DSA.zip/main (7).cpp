#include <iostream>
#include <stack>
#include <queue>
using namespace std;

class GarageSystem {
private:
    queue<int> road;
    stack<int> garage;

public:
    void On_road(int id) {
        road.push(id);
        cout << "Truck " << id << " is now on the road.\n";
    }

    void Enter_garage() {
        if (road.empty()) {
            cout << "No trucks on road to enter the garage.\n";
            return;
        }
        int id = road.front();
        road.pop();
        garage.push(id);
        cout << "Truck " << id << " entered the garage.\n";
    }

    void Exit_garage(int id) {
        if (garage.empty()) {
            cout << "Garage is empty.\n";
            return;
        }
        if (garage.top() == id) {
            cout << "Truck " << id << " exited the garage.\n";
            garage.pop();
        } else {
            cout << "Error: Truck " << id << " is not near the garage door!\n";
        }
    }

    void Show_trucks(string where) {
        if (where == "road") {
            if (road.empty()) cout << "No trucks on the road.\n";
            else {
                cout << "\nTrucks on Road: ";
                queue<int> temp = road;
                while (!temp.empty()) {
                    cout << temp.front() << " ";
                    temp.pop();
                }
                cout << endl;
            }
        } else if (where == "garage") {
            if (garage.empty()) cout << "Garage is empty.\n";
            else {
                cout << "\nTrucks in Garage (top = near door): ";
                stack<int> temp = garage;
                while (!temp.empty()) {
                    cout << temp.top() << " ";
                    temp.pop();
                }
                cout << endl;
            }
        } else {
            cout << "Invalid option. Use 'road' or 'garage'.\n";
        }
    }
};

int main() {
    GarageSystem gs;
    gs.On_road(101);
    gs.On_road(102);
    gs.On_road(103);
    gs.Enter_garage();
    gs.Enter_garage();
    gs.Show_trucks("garage");
    gs.Exit_garage(101);
    gs.Exit_garage(102);
    gs.Show_trucks("garage");
    return 0;
}
