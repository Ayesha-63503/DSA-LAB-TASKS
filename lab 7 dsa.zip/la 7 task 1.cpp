#include <iostream>
#include <string>
using namespace std;

class BookNode {
public:
    string title;
    double price;
    int edition;
    int pages;
    BookNode* next;

    BookNode(string t, double p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = NULL;
    }
};
class BookStack {
private:
    BookNode* top; 
				public:
    BookStack() {
        top = NULL;
    }
void push(string title, double price, int edition, int pages) {
        BookNode* newBook = new BookNode(title, price, edition, pages);
        newBook->next = top;
        top = newBook;
        cout << "Book \"" << title << "\" pushed onto stack.\n";
    }

    void pop() {
        if (top == NULL) {
            cout << "Stack is empty! Cannot pop.\n";
            return;
        }
        cout << "Popping book: " << top->title << endl;
        BookNode* temp = top;
        top = top->next;
        delete temp;
    }

    void peek() {
        if (top == NULL) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "Top Book: " << top->title << ", Price: " << top->price
             << ", Edition: " << top->edition << ", Pages: " << top->pages << endl;
    }

    void display() {
        if (top == NULL) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\nBooks currently in stack:\n";
        BookNode* temp = top;
        while (temp != NULL) {
            cout << "Title: " << temp->title
                 << ", Price: " << temp->price
                 << ", Edition: " << temp->edition
                 << ", Pages: " << temp->pages << endl;
            temp = temp->next;
        }
    }
};
int main() {
    BookStack stack;

    stack.push("Book A", 500, 1, 250);
    stack.push("Book B", 450, 2, 300);
    stack.push("Book C", 600, 3, 400);
    stack.push("Book D", 550, 2, 350);
    stack.push("Book E", 700, 4, 500);

    cout << "\n--- Peek Top Book ---\n";
    stack.peek();
    cout << "\n--- Pop 2 Books ---\n";
    stack.pop();
    stack.pop();
    cout << "\n--- Remaining Books ---\n";
    stack.display();

    return 0;
}
