#include <iostream>
using namespace std;

class Inventory {
public:
    int serialNum;
    int manufactYear;
    int lotNum;

    Inventory(int s = 0, int y = 0, int l = 0) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void display() {
        cout << "Serial Number: " << serialNum
             << ", Year: " << manufactYear
             << ", Lot Number: " << lotNum << endl;
    }
};
class Node {
public:
    Inventory data;
    Node* next;
    Node(Inventory i) {
        data = i;
        next = NULL;
    }
};

class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    void push(Inventory i) {
        Node* newNode = new Node(i);
        newNode->next = top;
        top = newNode;
    }

    void pop() {
        if (top == NULL) {
            cout << "Inventory is empty!\n";
            return;
        }
        cout << "\nRemoving top part:\n";
        top->data.display();
        Node* temp = top;
        top = top->next;
        delete temp;
    }

    void displayAll() {
        if (top == NULL) {
            cout << "No parts in inventory.\n";
            return;
        }
        cout << "\nParts remaining in inventory:\n";
        Node* temp = top;
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
    }
};

// Main function
int main() {
    Stack inventoryStack;
    int choice;

    do {
        cout << "\n--- Inventory Menu ---\n";
        cout << "1. Add a part\n";
        cout << "2. Remove a part\n";
        cout << "3. Exit and show remaining parts\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory item(serial, year, lot);
            inventoryStack.push(item);
        }
        else if (choice == 2) {
            inventoryStack.pop();
        }
        else if (choice == 3) {
            cout << "\nExiting...\n";
        }
        else {
            cout << "Invalid choice!\n";
        }
    } while (choice != 3);
    inventoryStack.displayAll();

    return 0;
}
