#include <iostream>
using namespace std;

int main() {
    int* ptr = nullptr;  

    
    if (ptr == nullptr) {
        cout << "Pointer is null. Assigning it to a variable's address.\n";
    }

    int x = 42;
    ptr = &x; 

   
    if (ptr != nullptr) {
        cout << "Pointer is now assigned.\n";
        cout << "Value pointed to by ptr: " << *ptr << endl;
    }

    return 0;
}
