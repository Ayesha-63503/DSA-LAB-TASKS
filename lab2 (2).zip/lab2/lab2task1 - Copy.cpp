#include <iostream>
using namespace std;

int main() {
    int x = 10;       
    int* p = &x;      
    int** pp = &p;     
    cout << "Original value of x:\n";
    cout << "x = " << x << endl;
    cout << "*p = " << *p << endl;
    cout << "**pp = " << **pp << endl;

    
    **pp = 20;

    cout << "\nAfter modifying x via **pp:\n";
    cout << "x = " << x << endl;
    cout << "*p = " << *p << endl;
    cout << "**pp = " << **pp << endl;

    return 0;
}
