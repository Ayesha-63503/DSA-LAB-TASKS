#include <iostream>
using namespace std;

struct Student {
    int id;
    string name;
    int marks;
};

int main() {
    Student s1 = {101, "Amna", 20};
    Student* ptr = &s1;       

    
    cout << "ID: " << ptr->id << endl;      
    cout << "name " << ptr->name << endl;
  cout << "marks " << ptr->marks<< endl;
  
  
    ptr->id = 202;
    ptr->name = "ayesha";
    ptr->marks= 40;

    cout << "After modification:" << endl;
    cout << "ID: " << s1.id << endl;
    cout << "Name" << s1.name << endl;
      cout << "Marks" << s1.marks << endl;
    return 0;
}
